#include "test/jemalloc_test.h"

btalloc_n_gen(0)
